const express = require("express");
const {
  newOrder,
  getOrderBy,
  deleteMany,
  oderUpdate,
  getInvoice,
} = require("../../../controller/order/orderController");
const { isOurCustomer } = require("../../../../middleware/isUserExist");
const { ifCache, setCache } = require("../../../../middleware/cache");
const _ = express.Router();
_.post("/", isOurCustomer, newOrder);
//?req.body=first_name last_name , other order fields
_.get("/:id", getInvoice); 
_.get("/", ifCache, getOrderBy, setCache);
//? req.query=  customer_name, customer_eamil, customer_phone, payment_status, oder_status,date, fields,sortBy=last_two,latest,oldest

_.delete("/", deleteMany); //?req.body= idList of Order ids
_.patch("/:_id", oderUpdate);

module.exports = _;
