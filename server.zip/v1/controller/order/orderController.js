const {
  Unauthorized,
  NotAcceptable,
  NotFoundError,
} = require("../../../error/customError");
const { Order } = require("../../../model/order/orderModel");
const { Product } = require("../../../model/product/productModel");
const appStatus = require("../../../utils/appStatus");
const { tryCatch } = require("../../../utils/tryCatch");
const { User } = require("../../../model/user/userModel");
//### order Placed ###########
const newOrder = tryCatch(async (req, res, next) => {
  const customer_ref = req.customer_ref;

  if (!customer_ref) {
    return next(new NotAcceptable("Customer reference is required"));
  }

  const data = req.body;

  const new_order = new Order({
    ...data,
    customer_ref,
  });

  const save_order = await new_order.save();

  if (!save_order) {
    return next(new NotAcceptable("Order could not be saved"));
  }

  return appStatus(201, save_order, req, res, next);
  console.log("error3");
});

//### order get ,filter ,search ###########

const getOrderBy = tryCatch(async (req, res, next) => {
  const {
    customer_name,
    customer_eamil,
    customer_phone,
    payment_status,
    oder_status,
    invoice_id,
    sortBy,
    date,
    fields,
  } = req.query;

  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const math = fields
    ? fields
        .split(",")
        .map((field) => field.trim())
        .join(" ")
    : "";
  let searchQuery = {};

  if (typeof date === "string" && date !== undefined && date !== "") {
    let startDate = new Date(date);
    startDate.setHours(0, 0, 0, 0);
    let endDate = new Date(date);
    endDate.setHours(23, 59, 59, 999);
    searchQuery = {
      createdAt: { $gte: startDate, $lte: endDate },
    };
  }
  if (customer_name !== undefined && customer_name !== "") {
    searchQuery.customer_name = reg(customer_name);
  }
  if (invoice_id !== undefined && invoice_id !== "") {
    searchQuery.invoice_id = reg(invoice_id);
  }
  if (customer_eamil !== undefined && customer_eamil !== "") {
    console.log("customer_eamil");
    searchQuery.customer_eamil = reg(customer_eamil);
  }
  console.log(customer_phone);
  if (customer_phone !== undefined && customer_phone !== "") {
    console.log("customer_phone");
    searchQuery.customer_phone = reg(customer_phone);
  }
  if (oder_status !== undefined && oder_status !== "") {
    searchQuery.oder_status = reg(oder_status);
  }
  if (payment_status !== undefined && payment_status !== "") {
    searchQuery.payment_status = reg(payment_status);
  }

  const sortOptions = {};
  if (sortBy !== undefined && sortBy !== "") {
    if (sortOptions === "last_two") {
      const currentDate = new Date();
      const lastTwoDays = new Date();
      lastTwoDays.setDate(lastTwoDays.getDate() - 28);

      searchQuery = {
        createdAt: {
          $gte: lastTwoDays,
          $lte: currentDate,
        },
      };
    }
    if (sortOptions === "latest") {
      sortOptions.createdAt = -1;
    }
    if (sortOptions === "oldest") {
      sortOptions.createdAt = 1;
    }
  }

  const options = {
    page: page,
    limit: limit,
    select: math,
    lean: true,
    sort: sortOptions,

    populate: {
      path: "product_list.p_ref",
      model: "Product",
      select: "title sku brand category price discount thumb",
      lean: true,
    },
  };
  const orderByquery = await Order.paginate(searchQuery, options);
  const paginate = {
    totalDocs: orderByquery.totalDocs,
    limit: orderByquery.limit,
    totalPages: orderByquery.totalPages,
    page: orderByquery.page,
    pagingCounter: orderByquery.pagingCounter,
    hasPrevPage: orderByquery.hasPrevPage,
    hasNextPage: orderByquery.hasNextPage,
    prevPage: orderByquery.prevPage,
    nextPage: orderByquery.nextPage,
  };
  if (!orderByquery || orderByquery.length === 0) {
    return next(appError(404, "Not Found"));
  }
  res.locals.data = { orderByquery, paginate };
  next();
});

//### many delete ###########
const deleteMany = tryCatch(async (req, res, next) => {
  const { idList } = req.body;

  const result = await Order.deleteMany({ _id: { $in: idList } });

  if (result.deletedCount === 0) {
    return next(new NotFoundError("No orders found to delete."));
  }
  appStatus(204, "", req, res, next);
});

//### update order#####
const oderUpdate = tryCatch(async (req, res, next) => {
  const _id = req.params._id;
  const updateData = req.body.data;
  console.log(updateData);
  const checkOrder = await Order.findByIdAndUpdate(_id, updateData, {
    new: true,
  });
  if (!checkOrder) {
    return next(appError(404, "Order not found"));
  }
  //########## update quantity #######

  if (
    (checkOrder &&
      ["Order Confirmed", "Delivered"].includes(checkOrder.oder_status)) ||
    ["Payment Full"].includes(checkOrder.payment_status)
  ) {
    for (const { p_ref, quantity } of checkOrder.product_list) {
      console.log(p_ref);
      await Product.findByIdAndUpdate(
        p_ref,
        {
          $inc: { stock: -quantity },
        },
        { new: true }
      );
    }

    await User.findByIdAndUpdate(
      checkOrder.customer_ref,
      {
        $push: { order_list: checkOrder._id },
      },
      { new: true }
    );
  }

  appStatus(204, "", req, res, next);
});
//##### invoice #########
const getInvoice = tryCatch(async (req, res, next) => {
  const { id } = req.params;
  const inv = await Order.findById(id).populate({
    path: "product_list.p_ref",
    model: "Product",
  });

  if (!inv) {
    return next(new NotFoundError("Try AGain"));
  }
  appStatus(200, inv, req, res, next);
});

module.exports = {
  newOrder,
  getOrderBy,
  deleteMany,
  oderUpdate,
  getInvoice,
};

// regex
const reg = (shr) => {
  const regexQuery = new RegExp(shr, "i");

  return regexQuery;
};
