const mongoose = require("mongoose");
const { Schema } = mongoose;
const validator = require("validator");
const mongoosePaginate = require("mongoose-paginate-v2");
const { Product } = require("../product/productModel");
const { Shipping } = require("../shipping/shipModel");

const orderSchema = new Schema(
  {
    customer_ref: { type: Schema.Types.ObjectId, ref: "User" },
    product_list: [
      {
        p_ref: { type: Schema.Types.ObjectId, ref: "Product" },
        quantity: { type: Number, default: 1 },
        color: { type: String, default: "" },
        size: { type: String, default: "" },
      },
    ],
    regular_price: { type: Number, default: 0 },
    discount_price: { type: Number, default: 0 },
    offer_price: { type: Number, default: 0 },
    total_price: { type: Number, default: 0 },
    shipping: { type: Number, default: 0 },
    paid_amount: { type: Number, default: 0 },
    oder_status: {
      type: String,
      trim: true,
      default: "Placed",
      enum: [
        "Placed",
        "In Progress",
        "Order Confirmed",
        "Delivered",
        "Canceled",
      ],
    },
    payment_status: {
      type: String,
      default: "Pendding",
      enum: [
        "Pendding",
        "Payment Full",
        "Delivery Fee Paid",
        "Failed",
        "Order Canceled",
      ],
    },
    quantity: { type: Number, default: 1 },
    payment_by: {
      type: String,
      default: "Cash On Delivery",
      enum: ["Online Banking", "Cash On Delivery"],
    },
    payment_institute: {
      type: String,
      default: "",
    },
    customer_name: {
      type: String,
      required: true,
      trim: true,
      minLength: [3, "Name must at least 3 character"],
      maxLength: [15, "name is too large"],
    },
    customer_eamil: {
      type: String,
      required: true,
      validate: {
        validator: validator.isEmail,
        message: "Invalid email format",
      },
    },
    customer_phone: {
      type: String,
      required: true,
      validate: {
        validator: function (value) {
          return validator.isMobilePhone(value, "bn-BD");
        },
        message: "Invalid phone number for Bangladesh",
      },
    },

    city: {
      type: String,
      default: "",
    },

    country: {
      type: String,
      default: "",
    },

    area: {
      type: String,
      default: "",
    },
    house_nbr: {
      type: String,
      default: "",
    },
    road_nbr: {
      type: String,
      default: "",
    },
    post_code: {
      type: Number,
      default: 0,
    },
    address: {
      type: String,
      default: "",
    },
    tran_id: {
      type: String,
      default: "",
    },

    effective_delivery: {
      type: String,
      default: "Home",
      enum: ["Home", "Office"],
    },
    invoice_id: { type: String, default: "", index: true },
  },
  { timestamps: true }
);
//?##### invoice id#####
orderSchema.pre("save", function (next) {
  if (!this.invoice_id) {
    const inv = this._id.toString().slice(-6);
    this.invoice_id = inv;
  }
  next();
});
orderSchema.pre("save", function (next) {
  const totalQuantity = this.product_list.reduce(
    (acc, item) => acc + item.quantity,
    0
  );

  this.quantity = totalQuantity;

  next();
});
//?################ Shipping and Calculate Price #########################

orderSchema.pre("save", async function (next) {
  try {
    const Order = this;

    // Fetch shipping information
    const shippingInfo = await Shipping.findById("66d6901edd7ae94ed1d08436");
    if (Order.city === "Dhaka") {
      Order.shipping = shippingInfo.in_dhaka;
    } else {
      Order.shipping = shippingInfo.out_dhaka;
    }

    // Calculate prices based on product list
    const productIds = Order.product_list.map((item) => item.p_ref);
    const products = await Product.find({ _id: { $in: productIds } });

    let totalRegularPrice = 0;
    let totalDiscountPrice = 0;

    Order.product_list.forEach((item) => {
      const product = products.find((p) => p._id.equals(item.p_ref));
      if (product) {
        totalRegularPrice += product.price * item.quantity;
        totalDiscountPrice +=
          (product.price - product.discount) * item.quantity;
      }
    });

    // Set the calculated prices
    Order.regular_price = totalRegularPrice;
    Order.discount_price = totalRegularPrice - totalDiscountPrice;
    Order.offer_price = totalDiscountPrice;
    Order.total_price = totalDiscountPrice + Order.shipping;

    next();
  } catch (error) {
    next(error);
  }
});



orderSchema.plugin(mongoosePaginate);

module.exports = {
  Order: mongoose.model("Order", orderSchema),
};
