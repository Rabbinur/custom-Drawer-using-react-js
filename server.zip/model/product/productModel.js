const mongoose = require("mongoose");
const { Schema } = mongoose;
const validator = require("validator");
const mongoosePaginate = require("mongoose-paginate-v2");

const productSchema = new Schema(
  {
    title: { type: String, required: true },
    category: { type: String, required: true },
    subcategory: { type: String, default: "" },
    brand: { type: String, default: "" },
    sku: { type: String, required: true },
    description: { type: String, default: "" },
    url: {
      type: [
        {
          public_id: { type: String, required: true },
          url: { type: String, required: true, validate: validator.isURL },
        },
      ],
      validate: {
        validator: function (value) {
          return value.length <= 6;
        },
        message: "You can only have up to 6 URLs",
      },
    },
    thumb: {
      public_id: { type: String, required: false },
      url: { type: String, required: false, validate: validator.isURL },
    },
    price: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    stock: { type: Number, default: 0 },
    color: { type: Array },
    size: { type: Array },

    isNew: { type: Boolean, default: false },
  },
  { timestamps: true }
);

productSchema.pre("save", function (next) {
  if (typeof this.isNew === "string") {
    this.isNew = this.isNew.toLowerCase() === "true";
  }

  next();
});

productSchema.plugin(mongoosePaginate);
module.exports = {
  Product: mongoose.model("Product", productSchema),
};
