import { Button } from "antd";

import "../Dashboard/style.css";

import { Link } from "react-router-dom";
import { AiFillEdit, AiFillDelete } from "react-icons/ai";
import { useState } from "react";

const AdminProductLists = ({ product, handleDelete, index }) => {
  const {
    category,
    sku,
    title,
    stock,
    brand,
    price,
    discount,
    _id,
    thumb,
    url,
    color,
    size,
    isNew,
    subcategory,
  } = product;
  //
  console.log(product);
  const [show, setShow] = useState(false);
  const handleShow = () => {
    setShow(!show);
  };

  return (
    <>
      <tr className={`${(index - 1) % 2 == 0 ? " bg-white  " : "bg-white  "} `}>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {index}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {title}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          <img
            src={url[0]?.url}
            alt="product thumb.url"
            className="h-10 mx-auto"
          />
        </td>

        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {category}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {brand}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {isNew ? "New" : ""}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {size?.join(",")}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {color?.join(",")}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {sku}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {price}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {" "}
          {discount}tk
        </td>

        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          {stock}
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          <button onClick={handleShow}>view</button>
        </td>
        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          <Link
            to={
              subcategory && subcategory !== ""
                ? `/edit-product/${brand}/${category}/${subcategory}/${title}`
                : `/edit-product/${brand}/${category}/${title}`
            }
          >
            <p className="flex items-center justify-center text-xs font-bold text-black font-bold  text-primary_hov">
              {" "}
              <span className="mr-2 text-xs text-black">
                <AiFillEdit></AiFillEdit>
              </span>
            </p>
          </Link>
        </td>

        <td className="px-2 py-2 text-xs text-black font-bold  capitalize whitespace-nowrap">
          <Button
            type="submit"
            className="flex items-center p-0 mx-auto text-xs  text-black font-bold  "
            onClick={() => handleDelete(_id)}
          >
            <span className="mr-2 text-xs text-black">
              <AiFillDelete></AiFillDelete>
            </span>
          </Button>
        </td>
      </tr>
      {show && (
        <div className="fixed inset-0 z-50 overflow-auto bg-gray-800 bg-opacity-75 flex">
          <div className="relative p-8 bg-white w-full max-w-2xl m-auto flex-col flex rounded-lg shadow-lg">
            <h2 className="text-xl font-bold mb-4">{product?.title}</h2>

            {/* Product Images */}
            <div className="mb-4">
              <div className="flex space-x-2 overflow-x-auto">
                {product?.url?.map((image, index) => (
                  <img
                    key={index}
                    src={image?.url}
                    alt={`Product image ${index + 1}`}
                    className="w-24 h-24 object-cover rounded-lg shadow-md"
                  />
                ))}
              </div>
            </div>
            <div className="flex space-x-2 overflow-x-auto">
              <img
                src={product?.thumb?.url}
                alt={`thumb image`}
                className="w-24 h-24 object-cover rounded-lg shadow-md"
              />
            </div>
            {/* Product Information */}
            <div className="mb-4">
              <p>
                <strong>Category:</strong> {product?.category}
              </p>
              <p>
                <strong>Brand:</strong> {product?.brand}
              </p>
              <p>
                <strong>SKU:</strong> {product?.sku}
              </p>
              <p>
                <strong>Description:</strong> {product?.description}
              </p>
              <p>
                <strong>Price:</strong> {product?.price.toFixed(2)}tk
              </p>
              <p>
                <strong>Discount:</strong> {product?.discount}tk
              </p>
              <p>
                <strong>Stock:</strong> {product?.stock}
              </p>
              <p>
                <strong>Colors:</strong> {product?.color?.join(",")}
              </p>
              <p>
                <strong>Sizes:</strong> {product?.size?.join(",")}
              </p>
              <p>
                <strong>New Arrival:</strong> {product?.isNew ? "Yes" : "No"}
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end">
              <Link
                to={
                  product?.subcategory && product?.subcategory !== ""
                    ? `/edit-product/${product?.brand}/${product?.category}/${product?.subcategory}/${product?.title}`
                    : `/edit-product/${product?.brand}/${product?.category}/${product?.title}`
                }
              >
                <button className="bg-white text-white font-bold py-2 px-4 rounded mr-2">
                  Edit
                </button>{" "}
              </Link>

              <button
                onClick={() => setShow(false)}
                className="bg-red-500 text-white font-bold py-2 px-4 rounded mr-2"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminProductLists;
