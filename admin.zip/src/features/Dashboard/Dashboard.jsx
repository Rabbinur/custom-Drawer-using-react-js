import { useEffect, useState } from "react";

import "./style.css";

import "../AdminProducts/product.css";
import { Link } from "react-router-dom";
import { Icon } from "@iconify/react";
import Api from "../../shared/Axios/axios";

const Dashboard = () => {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [totalOr, setTotal] = useState([]);
  const [user, setUser] = useState([]);
  //########### time #########
  const today = new Date();
  const twoDaysAgo = new Date(today);
  twoDaysAgo.setDate(today.getDate() - 2);
  const options = { day: "numeric", month: "long", year: "numeric" };

  const formattedTwoDaysAgo = twoDaysAgo.toLocaleDateString("en-US", options);
  const formattedToday = today.toLocaleDateString("en-US", options);
  //###########data fecthing#########
  const dashData = async () => {
    try {
      const res = await Api.get(`/dash`);

      if (res.status === 200) {
        setProducts(res.data.data.product);
        setOrders(res.data.data.order);
        setTotal(res.data.data.allOrder);
        setUser(res.data.data.user);
      }
    } catch (error) {
      console.error(error);
    }
  };
  console.log(orders);
  //########## delete ############
  const delOrderFn = async (id) => {
    try {
      const res = await Api.delete(`/orders`, {
        data: { idList: [id] },
      });
      console.log(res.status);
      dashData();
    } catch (error) {
      console.error(error);
    }
  };
  //########## effect #########
  useEffect(() => {
    dashData();
  }, []);
  console.log("sssssssssss", products);
  console.log(orders);
  return (
    <div className="container ps-32 md:ps-24 flex items-center justify-center w-full py-10 mx-auto box-border md:ps-20  ">
      <div className="w-full ">
        <h3
          className="mb-10 text-xl font-extrabold text-center uppercase md:text-4xl
         text-secondary underline"
        >
          Dashboard
        </h3>

        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 md:gap-10">
          {products?.map((pro, i) => (
            <Link to={`/admin/products-view/${pro?.category}`} key={i}>
              <div
                className="flex justify-between w-full p-4 text-center text-gray-900  
               transition-all duration-500 shadow-lg rounded-2xl text-light bg-white
                hover:bg-secondary hover:text-white"
              >
                <div>
                  <p className="mb-1 text-base font-medium text-start">
                    {pro?.category}
                  </p>
                  <h4 className="mb-0 text-4xl font-bold  text-start">
                    {" "}
                    {pro?.totalProducts}{" "}
                    <span className="text-sm">Stock: {pro?.totalStock}</span>
                  </h4>
                </div>
                <Icon
                  className="text-5xl"
                  icon="ant-design:product-outlined"
                ></Icon>
              </div>
            </Link>
          ))}
          <Link to="/admin/orders">
            {" "}
            <div
              className="flex justify-between w-full p-4 text-center
             transition-all duration-500 shadow-lg rounded-2xl
              text-white bg-primary hover:bg-white hover:text-black"
            >
              <div>
                <p className="mb-1 text-base font-medium">Total Orders</p>
                <h4 className="mb-0 text-4xl font-extrabold text-start">
                  {" "}
                  {totalOr?.length}
                </h4>
              </div>
              <Icon className="text-5xl" icon="lets-icons:order"></Icon>
            </div>
          </Link>
          <Link to="/admin/user">
            {" "}
            <div
              className="flex justify-between w-full p-4 text-center
             transition-all duration-500 shadow-lg
              rounded-2xl text-white bg-primary hover:bg-white hover:text-black"
            >
              <div>
                <p className="mb-1 text-base font-medium">Total Customer</p>
                <h4 className="mb-0 text-4xl font-extrabold text-start">
                  {" "}
                  {user?.length}
                </h4>
              </div>
              <Icon className="text-5xl" icon="lets-icons:order"></Icon>
            </div>
          </Link>
        </div>

        <div className="w-full mt-10">
          <h2 className="mb-4 text-4xl font-bold uppercase ">
            Recent Orders{" "}
            <span className="text-xs font-normal">
              ({formattedTwoDaysAgo} - {formattedToday})
            </span>
          </h2>
          <div className="w-full overflow-x-auto overflow-y-hidden text-black bg-white ">
            <table className="max-w-full text-black divide-y divide-gray-800">
              <thead className="">
                <tr>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Order Id
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Product Name
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Info
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Price
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    SKU
                  </th>

                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Date
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Customer
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Location
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Total Amount
                  </th>
                  <th
                    scope="col"
                    className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
                  >
                    Action
                  </th>
                </tr>
              </thead>
              <tbody className="">
                {orders?.length > 0 ? (
                  orders
                    ?.sort(
                      (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
                    )
                    ?.map((order, index) => {
                      return (
                        <tr
                          key={order?.id}
                          className={`${index % 2 == 0 ? " bg-white " : ""} `}
                        >
                          <td
                            className="px-2 py-2 text-xs text-black
                           capitalize whitespace-nowrap"
                          >
                            {order?.invoice_id}
                          </td>
                          <td
                            className="px-2 py-2 text-xs text-black
                           capitalize whitespace-nowrap"
                          >
                            {order?.product_list?.map((item, i) => (
                              <div
                                key={i}
                                className="text-xs text-black border-b"
                              >
                                {item?.p_ref?.title}
                                <br />
                                <span className="sm">
                                  Brand: {item?.p_ref?.brand}{" "}
                                </span>
                                <br />
                                <span className="sm">
                                  Cat: {item?.p_ref?.category}{" "}
                                </span>
                              </div>
                            ))}
                          </td>
                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap ">
                            {order?.product_list?.map((item, i) => (
                              <div
                                key={i}
                                className="text-xs text-black border-b "
                              >
                                {item.quantity} <br /> {item.color}
                                <br /> {item?.size}
                              </div>
                            ))}
                          </td>

                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            {order?.product_list?.map((item, i) => (
                              <div
                                key={i}
                                className="text-xs text-black border-b"
                              >
                                {item.p_ref?.price * item?.quantity -
                                  item?.p_ref?.discount * item?.quantity}{" "}
                                tk
                              </div>
                            ))}
                          </td>
                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            {order?.product_list?.map((item, i) => (
                              <div
                                key={i}
                                className="text-xs text-black border-b "
                              >
                                {item?.p_ref?.sku}
                              </div>
                            ))}
                          </td>

                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            {order?.createdAt &&
                              new Date(order.createdAt).toLocaleString("en-us")}
                          </td>
                          <td className="px-2 py-2 text-xs text-black whitespace-nowrap">
                            {order?.customer_name}
                            <hr />
                            {order?.customer_eamil}
                            <hr />
                            {order?.customer_phone}
                          </td>
                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            {order?.address}-{order?.post_code}
                            <hr />
                            {order?.effective_delivery}
                          </td>
                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            {order?.offer_price} tk
                            <br />
                            {order?.payment_status}
                            <br></br>
                            {order?.oder_status}
                          </td>
                          <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                            <Link
                              to={`/admin/orders/${order?._id}`}
                              className="cursor-pointer"
                            >
                              {" "}
                              View
                            </Link>
                            <br />
                            <br></br>
                            <p
                              onClick={() => delOrderFn(order?._id)}
                              className="cursor-pointer"
                            >
                              {" "}
                              Delete
                            </p>
                          </td>
                        </tr>
                      );
                    })
                ) : (
                  <p className="p-5 font-bold text-center text-black uppercase">
                    No order to show
                  </p>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
