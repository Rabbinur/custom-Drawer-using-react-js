import { useEffect } from "react";
import { useState } from "react";
import "../AdminProducts/product.css";
import Api from "../../shared/Axios/axios";
import { Link } from "react-router-dom";
import { useThrottle } from "@custom-react-hooks/use-throttle";
const AdminOrders = () => {
  const [orders, setorders] = useState([]);
  const [pagi, setPagi] = useState({});
  const [reload] = useState(false);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [searchSKU, setSearchSKU] = useState("");
  const [payment, setPayment] = useState("");
  const [odr, setOdd] = useState("");
  const [invoice, setInvoice] = useState("");
  const [searchCustomerNo, setSearchCustomerNo] = useState("");
  const [searchCategoryName, setSearchCategoryName] = useState("");
  const shr = useThrottle(searchSKU, 1000);
  const email = useThrottle(searchCategoryName, 1000);
  const phone = useThrottle(searchCustomerNo, 1000);
  const payy = useThrottle(payment, 1000);
  const os = useThrottle(odr, 1000);
  const iV = useThrottle(invoice, 1000);
  //############### fetch ####################
  const fetchData = async (sku, em, ph, p, o, pg, li, inv) => {
    const params = new URLSearchParams();

    if (em) params.append("customer_eamil", em);
    if (ph) params.append("customer_phone", ph);
    if (sku) params.append("date", sku);
    if (p) params.append("payment_status", p);
    if (o) params.append("oder_status", o);
    if (inv) params.append("invoice_id", inv);
    params.append("page", pg);
    params.append("limit", li);

    try {
      const res = await Api.get(`/orders?${params.toString()}`);
      setorders(res.data.data.orderByquery.docs);
      setPagi(res.data.data.paginate);
    } catch (error) {
      console.error(error);
    }
  };

  //########## delete ############
  const delOrderFn = async (id) => {
    try {
      await Api.delete(`/orders`, {
        data: { idList: [id] },
      });

      fetchData();
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchData(shr, email, phone, payy, os, page, limit, iV);
  }, [reload, shr, email, phone, payy, os, page, limit, iV]);
  //############
  const pay = ["Pendding", "Payment Confirmed", "Order Canceled"];
  const od = [
    "Placed",
    "In Progress",
    "Order Confirmed",
    "Delivered",
    "Canceled",
  ];
  const lit = ["20", "30", "40", "50", "100", "150"];
  console.log(orders);
  return (
    <div className="w-full ps-28 lg:ps-10 pr-10 py-20">
      <h3
        className="mb-10 text-xl font-extrabold text-center uppercase md:text-4xl
       text-primary underline   "
      >
        Orders Information ({orders?.length})
      </h3>
      <div className="flex justify-center items-center">
        {" "}
        <div>
          <input
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="date"
            placeholder="Search SKU"
            value={searchSKU}
            onChange={(e) => setSearchSKU(e.target.value)}
          />
          <input
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="text"
            placeholder="Phone"
            value={searchCustomerNo}
            onChange={(e) => setSearchCustomerNo(e.target.value)}
          />
          <input
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="text"
            placeholder="order Id"
            value={invoice}
            onChange={(e) => setInvoice(e.target.value)}
          />
          <input
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="text"
            placeholder="Eamil"
            value={searchCategoryName}
            onChange={(e) => setSearchCategoryName(e.target.value)}
          />
          <select
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="text"
            placeholder="Payment Status"
            onChange={(e) => setPayment(e.target.value)}
          >
            <option value={""}>Payment Status</option>
            {pay.map((it, i) => (
              <option key={i} value={it}>
                {it}
              </option>
            ))}
          </select>
          <select
            className="px-3 py-2 mb-5 mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
            type="text"
            placeholder="Payment Status"
            onChange={(e) => setOdd(e.target.value)}
          >
            <option value={""}>Order Status</option>
            {od.map((it, i) => (
              <option key={i} value={it}>
                {it}
              </option>
            ))}
          </select>
        </div>{" "}
      </div>

      <div className="w-full overflow-x-auto overflow-y-hidden bg-white">
        <table className="max-w-full text-black divide-y divide-gray-200">
          <thead className="">
            <tr>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Order id
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Order View
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Product Name
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Info
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Price
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                SKU
              </th>

              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Date
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Customer
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Location
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Total Amount
              </th>
              <th
                scope="col"
                className="px-2 py-2 text-xs font-medium tracking-wider text-left uppercase whitespace-nowrap"
              >
                Action
              </th>
            </tr>
          </thead>
          <tbody className="">
            {orders?.length > 0 ? (
              orders
                ?.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                ?.map((order, index) => {
                  return (
                    <tr
                      key={order.id}
                      className={`${index % 2 == 0 ? " bg-white " : ""} `}
                    >
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order?.invoice_id}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        <Link
                          to={`/admin/orders/${order?._id}`}
                          className="cursor-pointer"
                        >
                          {" "}
                          View
                        </Link>
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order?.product_list?.map((item, i) => (
                          <div key={i} className="text-xs text-black border-b">
                            {item?.p_ref?.title}
                            <br />
                            <span className="sm">
                              Brand: {item?.p_ref?.brand}{" "}
                            </span>
                            <br />
                            <span className="sm">
                              Cat: {item?.p_ref?.category}{" "}
                            </span>
                          </div>
                        ))}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap ">
                        {order?.product_list?.map((item, i) => (
                          <div key={i} className="text-xs text-black border-b ">
                            {item?.quantity} <br /> {item?.color}
                            <br /> {item?.size}
                          </div>
                        ))}
                      </td>

                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order?.product_list?.map((item, i) => (
                          <div key={i} className="text-xs text-black border-b">
                            {item.p_ref?.price * item?.quantity -
                              item?.p_ref?.discount * item?.quantity}{" "}
                            tk
                          </div>
                        ))}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order.product_list?.map((item, i) => (
                          <div key={i} className="text-xs text-black border-b ">
                            {item?.p_ref?.sku}
                          </div>
                        ))}
                      </td>

                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order.createdAt &&
                          new Date(order.createdAt).toLocaleString("en-us")}
                      </td>
                      <td className="px-2 py-2 text-xs text-black whitespace-nowrap">
                        {order.customer_name}
                        <hr />
                        {order.customer_eamil}
                        <hr />
                        {order.customer_phone}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order.address}-{order.post_code}
                        <hr />
                        {order.effective_delivery}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        {order?.offer_price} tk
                        <br />
                        {order?.payment_status}
                        <br></br>
                        {order?.oder_status}
                      </td>
                      <td className="px-2 py-2 text-xs text-black capitalize whitespace-nowrap">
                        <Link
                          to={`/admin/orders/${order?._id}`}
                          className="cursor-pointer"
                        >
                          {" "}
                          View
                        </Link>
                        <br />
                        <br></br>
                        <p
                          onClick={() => delOrderFn(order?._id)}
                          className="cursor-pointer"
                        >
                          {" "}
                          Delete
                        </p>
                      </td>
                    </tr>
                  );
                })
            ) : (
              <p className="p-5 font-bold text-center text-black uppercase">
                No order to show
              </p>
            )}
          </tbody>
        </table>
      </div>
      <div className="flex justify-center items-center gap-x-10 my-5">
        <p
          onClick={() => setLimit(pagi?.prevPage)}
          className="text-lg font-semibold cursor-pointer"
        >
          Prev
        </p>
        <p
          onClick={() => {
            setSearchSKU(""),
              setPayment(""),
              setOdd(""),
              setSearchCustomerNo(""),
              setSearchCategoryName(""),
              setInvoice(""),
              setPage(1),
              setLimit(10);
          }}
          className="text-lg font-semibold cursor-pointer"
        >
          Reset
        </p>
        <p
          onClick={() => setLimit(pagi?.nextPage)}
          className="text-lg font-semibold cursor-pointer"
        >
          Next
        </p>

        <select
          className="px-3 py-2  mr-2 text-sm transition-all duration-300 border rounded outline-none focus:shadow text-black  border-black"
          type="text"
          onChange={(e) => setLimit(e.target.value)}
        >
          <option value={10}>Limit</option>
          {lit.map((it, i) => (
            <option key={i} value={it}>
              {it}
            </option>
          ))}
        </select>
      </div>
      <div className="mt-4 pagination"></div>
    </div>
    // </div>
  );
};

export default AdminOrders;
