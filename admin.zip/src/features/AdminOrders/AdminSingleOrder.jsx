import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import Invoice from "../Invoice/Invoice";
import Api from "../../shared/Axios/axios";

const payment = ["Pendding", "Payment Confirmed", "Order Canceled"];
const OrderStatus = [
  "Placed",
  "In Progress",
  "Order Confirmed",
  "Delivered",
  "Canceled",
];
const AdminSingleOrder = () => {
  const [order, setOrderData] = useState({});

  const { id } = useParams();
  const [status, setStatus] = useState({
    id: "",
    type: "",
    status: "",
  });
  const [loading, setLoading] = useState(false);

  //##### get #################
  const getOrder = async () => {
    try {
      const res = await Api.get(`/orders/${id}`);
      setOrderData(res.data.data);
    } catch (error) {
      console.error(error.code);
    }
  };
  useEffect(() => {
    getOrder();
  }, [id]);
  const rend = (i) => {
    if (i === 1) {
      getOrder();
    }
  };

  //##########Pataho start  ###########
  const upFun = async (id, type, status) => {
    if (id === "" || type === "" || status === "") {
      return;
    }
    setLoading(true);
    try {
      console.log(id);
      const res = await Api.patch(`/orders/${id}`, {
        data: { [type]: status },
      });
      console.log(res);
      if (res.status === 204) {
        setStatus({
          id: "",
          type: "",
          status: "",
        });
        getOrder();
        alert("Updated");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    upFun(status?.id, status?.type, status?.status);
  }, [status?.id, status?.type, status?.status]);
  //################## use Effect ##############
  const mx = order?.product_list?.map((it) => it.p_ref);

  //################## use Effect end ##############

  return (
    <div className="container gri w-full  gap-10 py-5 mx-auto ps-20 md:py-5">
      <>
        <div className="flex items-start justify-center w-full h-full ">
          <div className="flex flex-col items-center justify-between w-full px-8 py-10 rounded-lg ">
            <h2 className="w-full my-3 text-xl font-bold text-center uppercase">
              {loading ? "Status..." : "Status"}
            </h2>{" "}
            <div className="flex gap-x-5 ">
              <select
                className="px-2 py-2 text-sm font-bold capitalize border shadow-sm outline-none bg-light text-primary"
                onChange={(e) =>
                  setStatus({
                    id: order?._id,
                    type: "payment_status",
                    status: e.target.value,
                  })
                }
              >
                <option
                  className="text-sm font-medium capitalize shadow"
                  value=""
                >
                  Payment
                </option>
                {payment?.map((status) => (
                  <option
                    key={status}
                    className="text-sm font-medium capitalize shadow"
                    value={status}
                  >
                    {status}
                  </option>
                ))}
              </select>
              <select
                className="px-2 py-2 text-sm font-bold capitalize border shadow-sm outline-none bg-light text-primary"
                onChange={(e) =>
                  setStatus({
                    id: order?._id,
                    type: "oder_status",
                    status: e.target.value,
                  })
                }
              >
                <option
                  className="text-sm font-medium capitalize shadow"
                  value=""
                >
                  Order
                </option>
                {OrderStatus?.map((status) => (
                  <option
                    key={status}
                    className="text-sm font-medium capitalize shadow"
                    value={status}
                  >
                    {status}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
        <div className="w-full col-span-2">
          <Invoice update={true} order={order} rend={rend} />
        </div>
        {/* product table */}
        <div className="p-8 rounded-lg w-full">
          <h1 className="text-center py-10 text-2xl font-semibold">
            Product Details Table
          </h1>
          <table className="table-auto w-full border-collapse border border-gray-300">
            <thead>
              <tr>
                <th className="border border-gray-300 p-4 bg-gray-100">
                  Product Details
                </th>
                <th className="border border-gray-300 p-4 text-center bg-gray-100">
                  Image
                </th>
              </tr>
            </thead>
            <tbody>
              {mx?.map((product) => (
                <tr key={product}>
                  <td className="border border-gray-300 p-4 align-top font-semibold">
                    <p className="text-xs font-bold">{product?.title}</p>

                    <p className="mt-2 text-xs">
                      Category: {product?.category}
                    </p>
                    <p className="mt-2 text-xs">Brand: {product?.brand}</p>
                    <p className="mt-2  text-xs">Price: {product?.price}tk</p>
                    <p className="mt-2 text-xs">
                      Discount: {product?.discount}tk
                    </p>
                    <p className="mt-2 text-xs">
                      Size: {product?.size?.join(",")}
                    </p>
                    <p className="mt-2 text-xs">
                      Color: {product?.color?.join(",")}
                    </p>
                    <p className="mt-2 text-xs">SKU: {product?.sku}</p>
                    <p className="mt-2 text-xs">Stock: {product?.stock}</p>
                  </td>
                  <td className="border border-gray-300 p-4">
                    <div className="flex flex-wrap gap-4">
                      {product?.url?.map((url, index) => (
                        <img
                          key={index}
                          src={url?.url}
                          alt={`Product image ${index + 1}`}
                          className="h-40 w-40 object-cover rounded-xl"
                        />
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    </div>
  );
};

export default AdminSingleOrder;
