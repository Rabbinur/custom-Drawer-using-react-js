import React from "react";
import Container from "../Container/Container";

const Payment = () => {
  return (
    <div>
      <Container>payment </Container>
    </div>
  );
};

export default Payment;
