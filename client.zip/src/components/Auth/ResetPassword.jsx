import React from "react";
import Container from "../Container/Container";

const ResetPassword = () => {
  return (
    <div>
      <Container>
        <div>reset pass</div>
      </Container>
    </div>
  );
};

export default ResetPassword;
